# A Little Reminder for You

A simple, mobile-friendly website designed for a QR code.

When someone scans the QR code:
- The website opens.
- Exactly one random life reminder appears automatically.
- There are no buttons, categories, or extra steps.
- A new visit can show a different reminder.

## Deploy to Vercel
1. Extract this ZIP.
2. Upload `index.html` to a GitHub repository.
3. In Vercel, choose **Add New → Project** and import the repository.
4. Deploy it as a static site. No build command is required.
5. Copy your deployed Vercel URL and use that URL to generate your QR code.

To add or edit messages, change the `reminders` array near the bottom of `index.html`.
